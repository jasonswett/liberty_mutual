presidents = ['George Washington', 'John Adams', 'Thomas Jefferson']
puts presidents

prime_numbers = [2, 3, 5, 7, 11]
puts prime_numbers
