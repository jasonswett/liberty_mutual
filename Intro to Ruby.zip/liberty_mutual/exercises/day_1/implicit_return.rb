def total_a
  return 10 + 20
end

def total_b
  10 + 20
end

puts total_a
puts total_b
