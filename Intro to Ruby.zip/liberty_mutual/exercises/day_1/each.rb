presidents = ['George Washington', 'John Adams', 'Thomas Jefferson']

presidents.each do |president|
  puts president.upcase
end

prime_numbers = [2, 3, 5, 7, 11]

prime_numbers.each do |prime_number|
  puts prime_number * 10
end
