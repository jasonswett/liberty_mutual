def print_name_a(options = {})
  puts options[:first_name]
  puts options[:last_name]
end

def print_name_b(options)
  puts options[:first_name]
  puts options[:last_name]
end

print_name_a
print_name_b
