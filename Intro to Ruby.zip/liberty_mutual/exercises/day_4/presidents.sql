CREATE TABLE presidents (
  id bigserial PRIMARY KEY,
  number int NOT NULL,
  first_name varchar(5) NOT NULL,
  last_name varchar(5) NOT NULL
);
